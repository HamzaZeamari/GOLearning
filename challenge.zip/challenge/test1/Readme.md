# Instructions

Implement the functions to pass the tests.


Reference: [link](https://en.wikipedia.org/wiki/Fold_(higher-order_function))

1. Do not change signature of functions
1. Do not change tests


