1. For the API part I used the Gin framework that I'm used to working with.

2. For the Docker part I've created a container that contains the Go project and launch the server listening at start.

3. Most of features I used are commented directly in the code and don't hesitate if you have questions about them. `:)`